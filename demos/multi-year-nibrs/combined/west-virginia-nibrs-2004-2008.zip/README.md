# West Virginia NIBRS data from 2004 through 2016

## Background

NIBRS (national incident-based reporting system) data is submitted to the FBI by state UCR program offices. To do so, they use the [UCR Data Collection Guidelines](https://ucr.fbi.gov/nibrs/nibrs_dcguide.pdf).

The [NIBRS User Manual](https://ucr.fbi.gov/nibrs/nibrs-user-manual) contains detailed information about what each offense code means as well as recommendations and considerations for analysis.

## Files included

### arrestee.csv

The columns in this file are:

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `arrest_type_name` - This refers to how a person was taken into custody
* `age_num` - The reported age or age range of the person who was arrested
* `sex_code` - The reported sex of the arrestee
* `race_code` - The reported race of the arrestee
* `arrest_type_code` - Indicates the type of of apprehension at the time of initial contact with the arrestee
* `arrest_date` - The date (year, month, and day) of an arrest
* `ethnicity` - The reported ethnicity of an arrestee in an incident, this is an optional data element
* `clearance_ind` -
* `under_18_disposition_code` - Used to report the nature of the arrestee's detention when the arrestee was 17 years of age or younger at the time of arrest
* `resident_status` - Indicates when the arrestee was a resident or nonresident of the jurisdiction in which the incident occurred
* `agency_name` - The name of the reporting agency
* `agency_type_name` -
* `city_name` - The city in which the reporting agency is located
* `state_abbr` - The state of the reporting agency
* `icpsr_zip` - The zip code associated with the reporting agency (pulled from the ICPSR report)
* `icpsr_lat` - The latitude associated with the reporting agency (pulled from the ICPSR report)
* `icpsr_lng` - The longitude associated with the reporting agency (pulled from the ICPSR report)

### incident.csv

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `incident_date` - Incident date indicates the year, month, and day when the incident occurred or the beginning time period that it occurred, as appropriate
* `agency_name` - The name of the reporting agency
* `city_name` - The city in which the reporting agency is located
* `icpsr_zip` - The zip code associated with the reporting agency (pulled from the ICPSR report)
* `icpsr_lat` - The latitude associated with the reporting agency (pulled from the ICPSR report)
* `icpsr_lng` - The longitude associated with the reporting agency (pulled from the ICPSR report)
* `state_abbr` - The state of the reporting agency

### offender.csv

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `race_code` - The reported race of the offender
* `sex_code` - The reported sex of the offender
* `age_num` - The reported age or age range of the offender
* `location_name` - Location name indicates the type of location/premises where each offense took place

### offense.csv

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `offense_name` - The name of the offense as defined by NIBRS codes
* `offense_id` -
* `location_name` - Location name indicates the type of location/premises where each offense took place.
* `weapon_name` - This indicates the type of weapon or force used by offender(s) – up to three types may be listed
* `bias_name` - An offense motivated, in whole or in part, by the offender’s bias against a race, religion, disability, sexual orientation, ethnicity, gender, or gender identity
* `attempt_complete_flag` - Indicates whether each offense in the incident was attempted or completed
* `suspected_using` - Indicates whether any of the offenders in the incident were suspected of consuming alcohol or using drugs/narcotics during or shortly before the incident, or using computer equipment to perpetrate the crime

### property.csv

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `prop_desc_name` - Refers to the description of the property that was burned, counterfeited, destroyed/damaged/vandalized, etc. as a result of the incident
* `date_recovered` - If law enforcement recovers previously stolen property they should report the month, day, and year of recovery
* `property_value` - Used to enter the total dollar value (in whole dollars) of the property impacted as a result of the incident
* `stolen_count` - Used to report how many items were stolen in an incident
* `drug_measure_name` - Indicates the types of drugs or narcotics seized in a drug case
* `drug_measure_code` -
* `est_drug_qty` - Used to indicate the quantity of drugs or narcotics seized in a drug case

### victim.csv

* `incident_key` - The primary key for this data set, all files can be joined on this key
* `ori` - The originating agency identifier is unique and assigned by the UCR program to the reporting agency
* `race_code` - The reported race of the victim
* `sex_code` - The reported sex of the victim
* `age_num` - The reported age or age range of the victim
* `ethnicity` - The reported ethnicity of a victim in an incident, this is an optional data element
* `location_name` - If the victim type entered in data element 25 was I=individual, then the person's ethnic origin is entered
